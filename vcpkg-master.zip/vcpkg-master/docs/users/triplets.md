# Triplets

The documentation for this topic has been moved to the following articles in [Microsoft Learn](https://learn.microsoft.com/vcpkg):

* [Triplet files](https://learn.microsoft.com/vcpkg/users/triplets)
* [Custom triplets](https://learn.microsoft.com/en-us/vcpkg/users/examples/overlay-triplets-linux-dynamic)
