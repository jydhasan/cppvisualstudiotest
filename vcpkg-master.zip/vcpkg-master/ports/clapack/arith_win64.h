/* Windows 64-bit */

#define IEEE_8087
#define Arith_Kind_ASL 1
#define Double_Align
#define X64_bit_pointers
#define NANCHECK
#define QNaN0 0x0
#define QNaN1 0x7ff80000
